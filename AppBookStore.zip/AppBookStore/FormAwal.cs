﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormAwal : Form
    {
        public FormAwal()
        {
            InitializeComponent();
        }

        private void btnLoginAdmin_Click(object sender, EventArgs e)
        {
            FormLoginAdmin formLoginAdmin = new FormLoginAdmin();
            formLoginAdmin.Show();
            this.Hide();
        }

        private void btnLoginPelanggan_Click(object sender, EventArgs e)
        {
            FormLoginPelanggan formLoginPelanggan = new FormLoginPelanggan();
            formLoginPelanggan.Show();
            this.Hide();
        }
    }
}
