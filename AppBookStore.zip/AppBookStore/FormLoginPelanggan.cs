﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormLoginPelanggan : Form
    {
        public FormLoginPelanggan()
        {
            InitializeComponent();
        }
        private NpgsqlCommand cmd;
        private DataSet ds;
        private NpgsqlDataAdapter da;
        private NpgsqlDataReader rd;

        koneksi Conn = new koneksi();

        private void btnLogin_Click(object sender, EventArgs e)
        {
            NpgsqlDataReader reader = null;
            NpgsqlConnection conn = Conn.GetConn();
            {
                conn.Open();
                cmd = new NpgsqlCommand("select * from pelanggan where id_pelanggan = '" + tbId.Text + "' and password_pelanggan = '" + tbPassword.Text + "'", conn);
                cmd.ExecuteNonQuery();
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    FormMenuPelanggan formMenuPelanggan = new FormMenuPelanggan();
                    formMenuPelanggan.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Id or Password Incorrect");
                }
            }
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            FormSignup formSignup = new FormSignup();
            formSignup.Show();
            this.Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FormAwal formAwal = new FormAwal();
            formAwal.Show();
            this.Close();
        }
    }
}
