﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormTransaksi : Form
    {
        public FormTransaksi()
        {
            InitializeComponent();
        }
        private NpgsqlCommand cmd;
        private DataSet ds;
        private NpgsqlDataAdapter da;
        private NpgsqlDataReader rd;
        koneksi Conn = new koneksi();

        void showDataBuku()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from buku", conn);
            ds = new DataSet();
            da = new NpgsqlDataAdapter(cmd);
            da.Fill(ds, "buku");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "buku";
            dataGridView1.Refresh();
        }
        void tampilanAwal()
        {
            tbIDTrans.Text = "";
            cbIDPlgn.Text = "";
            tbAlamatPlgn.Text = "";
            tbNamaPlgn.Text = "";
            tbTeleponPlgn.Text = "";
            cbIDAdm.Text = "";
            tbTotal.Text = "";
            tbBayar.Text = "";
            tbKembali.Text = "";
        }
        void bersihkan()
        {
            cbIDbku.Text = "";
            tbJudul.Text = "";
            tbHarga.Text = "";
            tbJumlah.Text = "";
        }
        void id()
        {
            long hitung;
            string urutan;
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select id_transaksi from transaksi where id_transaksi in(select max(id_transaksi) from transaksi) order by id_transaksi desc", conn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                hitung = Convert.ToInt64(rd[0].ToString().Substring(rd["id_transaksi"].ToString().Length - 4, 4)) + 1;
                string urutanID = "000" + hitung;
                urutan = "XXX" + urutanID.Substring(urutanID.Length - 4, 4);
            }
            else
            {
                urutan = "XXX0001";
            }
            rd.Close();
            tbIDTrans.Text = urutan;
            conn.Close();
        }
        void idPelanggan()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from pelanggan", conn);
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string id = rd.GetString(0);
                cbIDPlgn.Items.Add(id);
            }
        }
        void idAdmin()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from admin", conn);
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string id = rd.GetString(0);
                cbIDAdm.Items.Add(id);
            }
        }
        void idBuku()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from buku", conn);
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string id = rd.GetString(0);
                cbIDbku.Items.Add(id);
            }
        }
        void buatTabel()
        {
            dataGridView2.Columns.Clear();
            dataGridView2.Columns.Add("ID Buku", "ID Buku");
            dataGridView2.Columns.Add("Judul", "Judul");
            dataGridView2.Columns.Add("Harga", "Harga");
            dataGridView2.Columns.Add("Jumlah", "Jumlah");
            dataGridView2.Columns.Add("Sub Total", "Sub Total");
        }

        void subtotal()
        {
            int total = 0;
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                total += Convert.ToInt32(dataGridView2.Rows[i].Cells[4].Value);
            }
            tbTotal.Text = total.ToString();
        }

        private void FormTransaksi_Load(object sender, EventArgs e)
        {
            tampilanAwal();
            bersihkan();
            showDataBuku();
            id();
            idPelanggan();
            idAdmin();
            idBuku();
            buatTabel();
            subtotal();
        }

        private void cbIDPlgn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("select * from pelanggan where id_pelanggan = '" + cbIDPlgn.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    tbNamaPlgn.Text = rd[1].ToString();
                    tbAlamatPlgn.Text = rd[2].ToString();
                    tbTeleponPlgn.Text = rd[3].ToString();
                }
                else
                {
                    MessageBox.Show("Data tidak ada!!!");
                }
            }
        }

        private void cbIDbku_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("select * from buku where id_buku = '" + cbIDbku.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    tbJudul.Text = rd[1].ToString();
                    tbHarga.Text = rd[6].ToString();
                }
                else
                {
                    MessageBox.Show("Data tidak ada!!!");
                }
            }
        }

        private void btnPilih_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(tbHarga.Text);
            int y = Convert.ToInt32(tbJumlah.Text);
            int z = x * y;
            dataGridView2.Rows.Add(cbIDbku.Text, tbJudul.Text, tbHarga.Text, tbJumlah.Text, Convert.ToString(z));
            subtotal();
            bersihkan();
        }

        private void tbBayar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (Convert.ToInt32(tbTotal.Text) > Convert.ToInt32(tbBayar.Text))
                {
                    MessageBox.Show("Pembayaran Kurang!");
                }
                else if (Convert.ToInt32(tbTotal.Text) == Convert.ToInt32(tbBayar.Text))
                {
                    tbKembali.Text = "0";
                }
                else
                {
                    int x = Convert.ToInt32(tbBayar.Text) - Convert.ToInt32(tbTotal.Text);
                    tbKembali.Text = Convert.ToString(x);
                }
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("insert into transaksi values('" + tbIDTrans.Text + "','" + cbIDPlgn.Text + "','" + tbNamaPlgn.Text + "','" + tbTotal.Text + "','" + tbBayar.Text + "','" + tbKembali.Text + "','" + cbIDAdm.Text + "')", conn);
            cmd.ExecuteNonQuery();

            for (int i = 0; i <= dataGridView2.Rows.Count; i++)
            {
                cmd = new NpgsqlCommand("insert into detail_transaksi values('" + tbIDTrans.Text + "','" + dataGridView2.Rows[i].Cells[0].Value + "','" + dataGridView2.Rows[i].Cells[1].Value + "','" + dataGridView2.Rows[i].Cells[2].Value + "','" + dataGridView2.Rows[i].Cells[3].Value + "','" + dataGridView2.Rows[i].Cells[4].Value + "')", conn);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Pembelian Sukses");
            tampilanAwal();
            bersihkan();
            id();
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
