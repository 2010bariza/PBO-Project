﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormDataTransaksi : Form
    {
        public FormDataTransaksi()
        {
            InitializeComponent();
        }
        private NpgsqlCommand cmd;
        private DataSet ds;
        private NpgsqlDataAdapter da;
        private NpgsqlDataReader rd;

        koneksi Conn = new koneksi();
        void showDataTransaksi()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from transaksi", conn);
            ds = new DataSet();
            da = new NpgsqlDataAdapter(cmd);
            da.Fill(ds, "transaksi");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "transaksi";
            dataGridView1.Refresh();
        }
        void showDetailTransaksi()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from detail_transaksi where id_transaksi = '" + comboBox1.Text + "'", conn);
            ds = new DataSet();
            da = new NpgsqlDataAdapter(cmd);
            da.Fill(ds, "detail_transaksi");
            dataGridView2.DataSource = ds;
            dataGridView2.DataMember = "detail_transaksi";
            dataGridView2.Refresh();
        }
        void idTransaksi()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from transaksi", conn);
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string id = rd.GetString(0);
                comboBox1.Items.Add(id);
            }
        }

        private void FormDataTransaksi_Load(object sender, EventArgs e)
        {
            showDataTransaksi();
            idTransaksi();
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            showDetailTransaksi();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
