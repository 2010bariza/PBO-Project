﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormDataAdmin : Form
    {
        public FormDataAdmin()
        {
            InitializeComponent();
        }
        private NpgsqlCommand cmd;
        private DataSet ds;
        private NpgsqlDataAdapter da;
        private NpgsqlDataReader rd;

        koneksi Conn = new koneksi();
        void id()
        {
            long hitung;
            string urutan;
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select id_admin from admin where id_admin in(select max(id_admin) from admin) order by id_admin desc", conn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                hitung = Convert.ToInt64(rd[0].ToString().Substring(rd["id_admin"].ToString().Length - 4, 4)) + 1;
                string urutanID = "000" + hitung;
                urutan = "ADM" + urutanID.Substring(urutanID.Length - 4, 4);
            }
            else
            {
                urutan = "ADM0001";
            }
            rd.Close();
            tbID.Text = urutan;
            conn.Close();
        }

        void tampilanAwal()
        {
            tbID.Text = "";
            tbNama.Text = "";
            tbAlamat.Text = "";
            tbTelepon.Text = "";
            tbEmail.Text = "";
            tbPassword.Text = "";
        }

        void showDataAdmin()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from admin", conn);
            ds = new DataSet();
            da = new NpgsqlDataAdapter(cmd);
            da.Fill(ds, "admin");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "admin";
            dataGridView1.Refresh();
        }

        private void FormDataAdmin_Load(object sender, EventArgs e)
        {
            tampilanAwal();
            id();
            showDataAdmin();
        }

        private void tbID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("select * from admin where id_admin = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    tbID.Text = rd[0].ToString();
                    tbNama.Text = rd[1].ToString();
                    tbAlamat.Text = rd[2].ToString();
                    tbTelepon.Text = rd[3].ToString();
                    tbEmail.Text = rd[4].ToString();
                    tbPassword.Text = rd[5].ToString();
                }
                else
                {
                    MessageBox.Show("Data tidak ada!!!");
                }
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || tbNama.Text.Trim() == "" || tbAlamat.Text.Trim() == "" || tbTelepon.Text.Trim() == "" || tbEmail.Text.Trim() == "" || tbPassword.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("insert into admin values('" + tbID.Text + "','" + tbNama.Text + "','" + tbAlamat.Text + "','" + tbTelepon.Text + "','" + tbEmail.Text + "','" + tbPassword.Text + "')", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data berhasil ditambahkan");
                tampilanAwal();
                id();
                showDataAdmin();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || tbNama.Text.Trim() == "" || tbAlamat.Text.Trim() == "" || tbTelepon.Text.Trim() == "" || tbEmail.Text.Trim() == "" || tbPassword.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("update admin set nama_admin = '" + tbNama.Text + "', alamat_admin = '" + tbAlamat.Text + "', telepon_admin = '" + tbTelepon.Text + "', email_admin = '" + tbEmail.Text + "', password_admin = '" + tbPassword.Text + "' where id_admin = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data berhasil diedit");
                tampilanAwal();
                id();
                showDataAdmin();
            }
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || tbNama.Text.Trim() == "" || tbAlamat.Text.Trim() == "" || tbTelepon.Text.Trim() == "" || tbEmail.Text.Trim() == "" || tbPassword.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("delete from admin where id_admin = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data berhasil dihapus");
                tampilanAwal();
                id();
                showDataAdmin();
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
