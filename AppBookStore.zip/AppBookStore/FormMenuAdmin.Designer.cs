﻿namespace AppBookStore
{
    partial class FormMenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenuAdmin));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dataAdminMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.dataPelangganMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.dataBukuMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.dataTransaksiMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.LogoutMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataAdminMenu,
            this.dataPelangganMenu,
            this.dataBukuMenu,
            this.dataTransaksiMenu,
            this.toolStripMenuItem1,
            this.LogoutMenu,
            this.exitMenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dataAdminMenu
            // 
            this.dataAdminMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataAdminMenu.Name = "dataAdminMenu";
            this.dataAdminMenu.Size = new System.Drawing.Size(82, 20);
            this.dataAdminMenu.Text = "Data Admin";
            this.dataAdminMenu.Click += new System.EventHandler(this.dataAdminMenu_Click);
            // 
            // dataPelangganMenu
            // 
            this.dataPelangganMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataPelangganMenu.Name = "dataPelangganMenu";
            this.dataPelangganMenu.Size = new System.Drawing.Size(102, 20);
            this.dataPelangganMenu.Text = "Data Pelanggan";
            this.dataPelangganMenu.Click += new System.EventHandler(this.dataPelangganMenu_Click);
            // 
            // dataBukuMenu
            // 
            this.dataBukuMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataBukuMenu.Name = "dataBukuMenu";
            this.dataBukuMenu.Size = new System.Drawing.Size(73, 20);
            this.dataBukuMenu.Text = "Data Buku";
            this.dataBukuMenu.Click += new System.EventHandler(this.dataBukuMenu_Click);
            // 
            // dataTransaksiMenu
            // 
            this.dataTransaksiMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataTransaksiMenu.Name = "dataTransaksiMenu";
            this.dataTransaksiMenu.Size = new System.Drawing.Size(93, 20);
            this.dataTransaksiMenu.Text = "Data Transaksi";
            this.dataTransaksiMenu.Click += new System.EventHandler(this.dataTransaksiMenu_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(22, 20);
            this.toolStripMenuItem1.Text = "|";
            // 
            // LogoutMenu
            // 
            this.LogoutMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.LogoutMenu.Name = "LogoutMenu";
            this.LogoutMenu.Size = new System.Drawing.Size(62, 20);
            this.LogoutMenu.Text = "Log Out";
            this.LogoutMenu.Click += new System.EventHandler(this.LogoutMenu_Click);
            // 
            // exitMenu
            // 
            this.exitMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.exitMenu.Name = "exitMenu";
            this.exitMenu.Size = new System.Drawing.Size(38, 20);
            this.exitMenu.Text = "Exit";
            this.exitMenu.Click += new System.EventHandler(this.exitMenu_Click);
            // 
            // FormMenuAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMenuAdmin";
            this.Text = "Menu Admin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dataAdminMenu;
        private System.Windows.Forms.ToolStripMenuItem dataPelangganMenu;
        private System.Windows.Forms.ToolStripMenuItem dataBukuMenu;
        private System.Windows.Forms.ToolStripMenuItem dataTransaksiMenu;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem LogoutMenu;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
    }
}