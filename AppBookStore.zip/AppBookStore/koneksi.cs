﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace AppBookStore
{
    internal class koneksi
    {
        public NpgsqlConnection GetConn()
        {
            NpgsqlConnection Conn = new NpgsqlConnection();
            Conn.ConnectionString = "Server=localhost;Port=5432;User Id=postgres;Password=12345678;Database=BookStore";
            return Conn;
        }
    }
}
