﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormDataBuku : Form
    {
        public FormDataBuku()
        {
            InitializeComponent();
        }
        private NpgsqlCommand cmd;
        private DataSet ds;
        private NpgsqlDataAdapter da;
        private NpgsqlDataReader rd;

        koneksi Conn = new koneksi();

        void id()
        {
            long hitung;
            string urutan;
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select id_buku from buku where id_buku in(select max(id_buku) from buku) order by id_buku desc", conn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                hitung = Convert.ToInt64(rd[0].ToString().Substring(rd["id_buku"].ToString().Length - 4, 4)) + 1;
                string urutanID = "000" + hitung;
                urutan = "BUKU" + urutanID.Substring(urutanID.Length - 4, 4);
            }
            else
            {
                urutan = "BUKU0001";
            }
            rd.Close();
            tbID.Text = urutan;
            conn.Close();
        }

        void tampilanAwal()
        {
            tbID.Text = "";
            tbJudul.Text = "";
            tbGenre.Text = "";
            tbPengarang.Text = "";
            tbPenerbit.Text = "";
            tbStok.Text = "";
            tbHarga.Text = "";
        }

        void showDataBuku()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from buku", conn);
            ds = new DataSet();
            da = new NpgsqlDataAdapter(cmd);
            da.Fill(ds, "buku");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "buku";
            dataGridView1.Refresh();
        }

        private void FormDataBuku_Load(object sender, EventArgs e)
        {
            tampilanAwal();
            id();
            showDataBuku();
        }

        private void tbID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("select * from buku where id_buku = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    tbID.Text = rd[0].ToString();
                    tbJudul.Text = rd[1].ToString();
                    tbGenre.Text = rd[2].ToString();
                    tbPengarang.Text = rd[3].ToString();
                    tbPenerbit.Text = rd[4].ToString();
                    tbStok.Text = rd[5].ToString();
                    tbHarga.Text = rd[6].ToString();
                }
                else
                {
                    MessageBox.Show("Data tidak ada!!!");
                }
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || tbJudul.Text.Trim() == "" || tbGenre.Text.Trim() == "" || tbPengarang.Text.Trim() == "" || tbPenerbit.Text.Trim() == "" || tbStok.Text.Trim() == "" || tbHarga.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("insert into buku values('" + tbID.Text + "','" + tbJudul.Text + "','" + tbGenre.Text + "','" + tbPengarang.Text + "','" + tbPenerbit.Text + "','" + tbStok.Text + "','" + tbHarga.Text + "')", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data berhasil ditambahkan");
                tampilanAwal();
                id();
                showDataBuku();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || tbJudul.Text.Trim() == "" || tbGenre.Text.Trim() == "" || tbPengarang.Text.Trim() == "" || tbPenerbit.Text.Trim() == "" || tbStok.Text.Trim() == "" || tbHarga.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("update buku set judul = '" + tbJudul.Text + "', genre = '" + tbGenre.Text + "', pengarang = '" + tbPengarang.Text + "', penerbit = '" + tbPenerbit.Text + "', stok = '" + tbStok.Text + "', harga = '" + tbHarga.Text + "' where id_buku = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data berhasil diedit");
                tampilanAwal();
                id();
                showDataBuku();
            }
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || tbJudul.Text.Trim() == "" || tbGenre.Text.Trim() == "" || tbPengarang.Text.Trim() == "" || tbPenerbit.Text.Trim() == "" || tbStok.Text.Trim() == "" || tbHarga.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("delete from buku where id_buku = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data berhasil dihapus");
                tampilanAwal();
                id();
                showDataBuku();
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
