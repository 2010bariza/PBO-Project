﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormDataPelanggan : Form
    {
        public FormDataPelanggan()
        {
            InitializeComponent();
        }
        private NpgsqlCommand cmd;
        private DataSet ds;
        private NpgsqlDataAdapter da;
        private NpgsqlDataReader rd;

        koneksi Conn = new koneksi();

        void tampilanAwal()
        {
            tbID.Text = "";
            tbNama.Text = "";
            tbAlamat.Text = "";
            tbTelepon.Text = "";
            tbEmail.Text = "";
            tbPassword.Text = "";
        }

        void showDataPelanggan()
        {
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select * from pelanggan", conn);
            ds = new DataSet();
            da = new NpgsqlDataAdapter(cmd);
            da.Fill(ds, "pelanggan");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "pelanggan";
            dataGridView1.Refresh();
        }

        private void FormDataPelanggan_Load(object sender, EventArgs e)
        {
            tampilanAwal();
            showDataPelanggan();
        }

        private void tbID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("select * from pelanggan where id_pelanggan = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    tbID.Text = rd[0].ToString();
                    tbNama.Text = rd[1].ToString();
                    tbAlamat.Text = rd[2].ToString();
                    tbTelepon.Text = rd[3].ToString();
                    tbEmail.Text = rd[4].ToString();
                    tbPassword.Text = rd[5].ToString();
                }
                else
                {
                    MessageBox.Show("Data tidak ada!!!");
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || tbNama.Text.Trim() == "" || tbAlamat.Text.Trim() == "" || tbTelepon.Text.Trim() == "" || tbEmail.Text.Trim() == "" || tbPassword.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("update pelanggan set nama_pelanggan = '" + tbNama.Text + "', alamat_pelanggan = '" + tbAlamat.Text + "', telepon_pelanggan = '" + tbTelepon.Text + "', email_pelanggan = '" + tbEmail.Text + "', password_pelanggan = '" + tbPassword.Text + "' where id_pelanggan = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data berhasil diedit");
                tampilanAwal();
                showDataPelanggan();
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || tbNama.Text.Trim() == "" || tbAlamat.Text.Trim() == "" || tbTelepon.Text.Trim() == "" || tbEmail.Text.Trim() == "" || tbPassword.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("delete from pelanggan where id_pelanggan = '" + tbID.Text + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data berhasil dihapus");
                tampilanAwal();
                showDataPelanggan();
            }
        }
    }
}
