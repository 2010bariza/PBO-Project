﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormSignup : Form
    {
        public FormSignup()
        {
            InitializeComponent();
        }
        private NpgsqlCommand cmd;
        private DataSet ds;
        private NpgsqlDataAdapter da;
        private NpgsqlDataReader rd;

        koneksi Conn = new koneksi();
        void id()
        {
            long hitung;
            string urutan;
            NpgsqlConnection conn = Conn.GetConn();
            conn.Open();
            cmd = new NpgsqlCommand("select id_pelanggan from pelanggan where id_pelanggan in(select max(id_pelanggan) from pelanggan) order by id_pelanggan desc", conn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                hitung = Convert.ToInt64(rd[0].ToString().Substring(rd["id_pelanggan"].ToString().Length - 4, 4)) + 1;
                string urutanID = "000" + hitung;
                urutan = "USR" + urutanID.Substring(urutanID.Length - 4, 4);
            }
            else
            {
                urutan = "USR0001";
            }
            rd.Close();
            tbId.Text = urutan;
            conn.Close();
        }

        private void FormSignup_Load(object sender, EventArgs e)
        {
            id();
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            if (tbId.Text.Trim() == "" || tbNama.Text.Trim() == "" || tbAlamat.Text.Trim() == "" || tbTelepon.Text.Trim() == "" || tbEmail.Text.Trim() == "" || tbPassword.Text.Trim() == "")
            {
                MessageBox.Show("Form tidak boleh kosong!!!");
            }
            else
            {
                NpgsqlConnection conn = Conn.GetConn();
                cmd = new NpgsqlCommand("insert into pelanggan values('" + tbId.Text + "','" + tbNama.Text + "','" + tbAlamat.Text + "','" + tbTelepon.Text + "','" + tbEmail.Text + "','" + tbPassword.Text + "')", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Sign Up Berhasil");

                FormMenuPelanggan formMenuPelanggan = new FormMenuPelanggan();
                formMenuPelanggan.Show();
                this.Hide();
            }
        }
    }
}
