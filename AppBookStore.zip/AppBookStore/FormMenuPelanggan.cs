﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormMenuPelanggan : Form
    {
        public FormMenuPelanggan()
        {
            InitializeComponent();
        }
        FormTransaksi transaksi;
        void transaksi_fromClosed(object sender, FormClosedEventArgs e)
        {
            transaksi = null;
        }

        private void TransaksiMenu_Click(object sender, EventArgs e)
        {
            if (transaksi == null)
            {
                transaksi = new FormTransaksi();
                transaksi.FormClosed += new FormClosedEventHandler(transaksi_fromClosed);
                transaksi.ShowDialog();
            }
            else
            {
                transaksi.Activate();
            }
        }

        private void LogoutMenu_Click(object sender, EventArgs e)
        {
            FormAwal formAwal = new FormAwal();
            formAwal.Show();
            this.Close();
        }

        private void exitMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
