﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AppBookStore
{
    public partial class FormMenuAdmin : Form
    {
        public FormMenuAdmin()
        {
            InitializeComponent();
        }
        FormDataAdmin dataAdmin;
        FormDataPelanggan dataPelanggan;
        FormDataBuku dataBuku;
        FormDataTransaksi dataTransaksi;

        void dataAdmin_fromClosed(object sender, FormClosedEventArgs e)
        {
            dataAdmin = null;
        }
        void dataPelanggan_fromClosed(object sender, FormClosedEventArgs e)
        {
            dataPelanggan = null;
        }
        void dataBuku_fromClosed(object sender, FormClosedEventArgs e)
        {
            dataBuku = null;
        }
        void dataTransaksi_fromClosed(object sender, FormClosedEventArgs e)
        {
            dataTransaksi = null;
        }

        private void dataAdminMenu_Click(object sender, EventArgs e)
        {
            if (dataAdmin == null)
            {
                dataAdmin = new FormDataAdmin();
                dataAdmin.FormClosed += new FormClosedEventHandler(dataAdmin_fromClosed);
                dataAdmin.ShowDialog();
            }
            else
            {
                dataAdmin.Activate();
            }
        }

        private void dataPelangganMenu_Click(object sender, EventArgs e)
        {
            if (dataPelanggan == null)
            {
                dataPelanggan = new FormDataPelanggan();
                dataPelanggan.FormClosed += new FormClosedEventHandler(dataPelanggan_fromClosed);
                dataPelanggan.ShowDialog();
            }
            else
            {
                dataPelanggan.Activate();
            }
        }

        private void dataBukuMenu_Click(object sender, EventArgs e)
        {
            if (dataBuku == null)
            {
                dataBuku = new FormDataBuku();
                dataBuku.FormClosed += new FormClosedEventHandler(dataBuku_fromClosed);
                dataBuku.ShowDialog();
            }
            else
            {
                dataBuku.Activate();
            }
        }

        private void dataTransaksiMenu_Click(object sender, EventArgs e)
        {
            if (dataTransaksi == null)
            {
                dataTransaksi = new FormDataTransaksi();
                dataTransaksi.FormClosed += new FormClosedEventHandler(dataTransaksi_fromClosed);
                dataTransaksi.ShowDialog();
            }
            else
            {
                dataBuku.Activate();
            }
        }

        private void LogoutMenu_Click(object sender, EventArgs e)
        {
            FormAwal formAwal = new FormAwal();
            formAwal.Show();
            this.Close();
        }

        private void exitMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
