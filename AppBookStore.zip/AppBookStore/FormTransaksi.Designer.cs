﻿namespace AppBookStore
{
    partial class FormTransaksi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTransaksi));
            this.label1 = new System.Windows.Forms.Label();
            this.btnPilih = new System.Windows.Forms.Button();
            this.tbJumlah = new System.Windows.Forms.TextBox();
            this.tbHarga = new System.Windows.Forms.TextBox();
            this.tbTeleponPlgn = new System.Windows.Forms.TextBox();
            this.tbAlamatPlgn = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.cbIDPlgn = new System.Windows.Forms.ComboBox();
            this.cbIDbku = new System.Windows.Forms.ComboBox();
            this.tbNamaPlgn = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbJudul = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbIDAdm = new System.Windows.Forms.ComboBox();
            this.tbIDTrans = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbKembali = new System.Windows.Forms.TextBox();
            this.tbBayar = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnBatal = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lato", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 23);
            this.label1.TabIndex = 111;
            this.label1.Text = "Daftar Buku";
            // 
            // btnPilih
            // 
            this.btnPilih.Location = new System.Drawing.Point(80, 181);
            this.btnPilih.Name = "btnPilih";
            this.btnPilih.Size = new System.Drawing.Size(94, 30);
            this.btnPilih.TabIndex = 86;
            this.btnPilih.Text = "PILIH";
            this.btnPilih.UseVisualStyleBackColor = true;
            this.btnPilih.Click += new System.EventHandler(this.btnPilih_Click);
            // 
            // tbJumlah
            // 
            this.tbJumlah.Location = new System.Drawing.Point(112, 128);
            this.tbJumlah.Name = "tbJumlah";
            this.tbJumlah.Size = new System.Drawing.Size(121, 27);
            this.tbJumlah.TabIndex = 84;
            // 
            // tbHarga
            // 
            this.tbHarga.Enabled = false;
            this.tbHarga.Location = new System.Drawing.Point(112, 95);
            this.tbHarga.Name = "tbHarga";
            this.tbHarga.Size = new System.Drawing.Size(121, 27);
            this.tbHarga.TabIndex = 83;
            // 
            // tbTeleponPlgn
            // 
            this.tbTeleponPlgn.Enabled = false;
            this.tbTeleponPlgn.Location = new System.Drawing.Point(125, 148);
            this.tbTeleponPlgn.Name = "tbTeleponPlgn";
            this.tbTeleponPlgn.Size = new System.Drawing.Size(110, 20);
            this.tbTeleponPlgn.TabIndex = 89;
            // 
            // tbAlamatPlgn
            // 
            this.tbAlamatPlgn.Enabled = false;
            this.tbAlamatPlgn.Location = new System.Drawing.Point(125, 115);
            this.tbAlamatPlgn.Name = "tbAlamatPlgn";
            this.tbAlamatPlgn.Size = new System.Drawing.Size(110, 20);
            this.tbAlamatPlgn.TabIndex = 88;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 59);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(690, 221);
            this.dataGridView1.TabIndex = 110;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 180);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 19);
            this.label15.TabIndex = 91;
            this.label15.Text = "Id Admin";
            // 
            // cbIDPlgn
            // 
            this.cbIDPlgn.FormattingEnabled = true;
            this.cbIDPlgn.Location = new System.Drawing.Point(125, 48);
            this.cbIDPlgn.Name = "cbIDPlgn";
            this.cbIDPlgn.Size = new System.Drawing.Size(110, 21);
            this.cbIDPlgn.TabIndex = 90;
            this.cbIDPlgn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbIDPlgn_KeyPress);
            // 
            // cbIDbku
            // 
            this.cbIDbku.FormattingEnabled = true;
            this.cbIDbku.Location = new System.Drawing.Point(112, 30);
            this.cbIDbku.Name = "cbIDbku";
            this.cbIDbku.Size = new System.Drawing.Size(121, 27);
            this.cbIDbku.TabIndex = 81;
            this.cbIDbku.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbIDbku_KeyPress);
            // 
            // tbNamaPlgn
            // 
            this.tbNamaPlgn.Enabled = false;
            this.tbNamaPlgn.Location = new System.Drawing.Point(125, 82);
            this.tbNamaPlgn.Name = "tbNamaPlgn";
            this.tbNamaPlgn.Size = new System.Drawing.Size(110, 20);
            this.tbNamaPlgn.TabIndex = 87;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 19);
            this.label5.TabIndex = 79;
            this.label5.Text = "Jumlah";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 19);
            this.label4.TabIndex = 78;
            this.label4.Text = "Harga";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 19);
            this.label2.TabIndex = 76;
            this.label2.Text = "Id Buku";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Silver;
            this.groupBox1.Controls.Add(this.btnPilih);
            this.groupBox1.Controls.Add(this.tbJumlah);
            this.groupBox1.Controls.Add(this.tbHarga);
            this.groupBox1.Controls.Add(this.tbJudul);
            this.groupBox1.Controls.Add(this.cbIDbku);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 299);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(262, 233);
            this.groupBox1.TabIndex = 112;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pilih Buku";
            // 
            // tbJudul
            // 
            this.tbJudul.Enabled = false;
            this.tbJudul.Location = new System.Drawing.Point(112, 62);
            this.tbJudul.Name = "tbJudul";
            this.tbJudul.Size = new System.Drawing.Size(121, 27);
            this.tbJudul.TabIndex = 82;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 19);
            this.label3.TabIndex = 77;
            this.label3.Text = "Judul";
            // 
            // cbIDAdm
            // 
            this.cbIDAdm.FormattingEnabled = true;
            this.cbIDAdm.Location = new System.Drawing.Point(125, 182);
            this.cbIDAdm.Name = "cbIDAdm";
            this.cbIDAdm.Size = new System.Drawing.Size(110, 21);
            this.cbIDAdm.TabIndex = 92;
            // 
            // tbIDTrans
            // 
            this.tbIDTrans.Enabled = false;
            this.tbIDTrans.Location = new System.Drawing.Point(125, 17);
            this.tbIDTrans.Name = "tbIDTrans";
            this.tbIDTrans.Size = new System.Drawing.Size(110, 20);
            this.tbIDTrans.TabIndex = 86;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 113);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 19);
            this.label10.TabIndex = 84;
            this.label10.Text = "Alamat";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 19);
            this.label9.TabIndex = 83;
            this.label9.Text = "Nama";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 19);
            this.label8.TabIndex = 82;
            this.label8.Text = "Id Pelanggan";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 19);
            this.label7.TabIndex = 81;
            this.label7.Text = "Id Transaksi";
            // 
            // btnSimpan
            // 
            this.btnSimpan.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSimpan.Location = new System.Drawing.Point(729, 457);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(110, 35);
            this.btnSimpan.TabIndex = 115;
            this.btnSimpan.Text = "SIMPAN";
            this.btnSimpan.UseVisualStyleBackColor = true;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // tbTotal
            // 
            this.tbTotal.Enabled = false;
            this.tbTotal.Location = new System.Drawing.Point(804, 324);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.Size = new System.Drawing.Size(150, 20);
            this.tbTotal.TabIndex = 121;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(725, 322);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 19);
            this.label14.TabIndex = 120;
            this.label14.Text = "Total";
            // 
            // tbKembali
            // 
            this.tbKembali.Enabled = false;
            this.tbKembali.Location = new System.Drawing.Point(804, 389);
            this.tbKembali.Name = "tbKembali";
            this.tbKembali.Size = new System.Drawing.Size(150, 20);
            this.tbKembali.TabIndex = 119;
            // 
            // tbBayar
            // 
            this.tbBayar.Location = new System.Drawing.Point(804, 354);
            this.tbBayar.Name = "tbBayar";
            this.tbBayar.Size = new System.Drawing.Size(150, 20);
            this.tbBayar.TabIndex = 116;
            this.tbBayar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbBayar_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(725, 387);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 19);
            this.label13.TabIndex = 118;
            this.label13.Text = "Kembali";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(725, 355);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 19);
            this.label12.TabIndex = 117;
            this.label12.Text = "Di Bayar";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(280, 298);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(422, 234);
            this.dataGridView2.TabIndex = 114;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Silver;
            this.groupBox2.Controls.Add(this.cbIDAdm);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.cbIDPlgn);
            this.groupBox2.Controls.Add(this.tbTeleponPlgn);
            this.groupBox2.Controls.Add(this.tbAlamatPlgn);
            this.groupBox2.Controls.Add(this.tbNamaPlgn);
            this.groupBox2.Controls.Add(this.tbIDTrans);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(719, 59);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(254, 220);
            this.groupBox2.TabIndex = 113;
            this.groupBox2.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 146);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 19);
            this.label11.TabIndex = 85;
            this.label11.Text = "No Telepon";
            // 
            // btnBatal
            // 
            this.btnBatal.Font = new System.Drawing.Font("Lato", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBatal.Location = new System.Drawing.Point(863, 457);
            this.btnBatal.Name = "btnBatal";
            this.btnBatal.Size = new System.Drawing.Size(110, 35);
            this.btnBatal.TabIndex = 122;
            this.btnBatal.Text = "BATAL";
            this.btnBatal.UseVisualStyleBackColor = true;
            this.btnBatal.Click += new System.EventHandler(this.btnBatal_Click);
            // 
            // FormTransaksi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(984, 555);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.tbTotal);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tbKembali);
            this.Controls.Add(this.tbBayar);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnBatal);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormTransaksi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transaksi";
            this.Load += new System.EventHandler(this.FormTransaksi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPilih;
        private System.Windows.Forms.TextBox tbJumlah;
        private System.Windows.Forms.TextBox tbHarga;
        private System.Windows.Forms.TextBox tbTeleponPlgn;
        private System.Windows.Forms.TextBox tbAlamatPlgn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cbIDPlgn;
        private System.Windows.Forms.ComboBox cbIDbku;
        private System.Windows.Forms.TextBox tbNamaPlgn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbJudul;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbIDAdm;
        private System.Windows.Forms.TextBox tbIDTrans;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbKembali;
        private System.Windows.Forms.TextBox tbBayar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnBatal;
    }
}